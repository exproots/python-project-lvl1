#!/usr/bin/env python3
from brain_games.logic_functions import get_game
from brain_games.games import brain_progression
def main():
    get_game(brain_progression)


if __name__ == '__main__':
    main()
